#!/bin/bash

cat /etc/passwd | cut -f 3 -d : > userinfo.txt
