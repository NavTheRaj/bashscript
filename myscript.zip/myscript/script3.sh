#!/bin/bash

        #! ifconfig | cut -f 1 -d: >out.txt

      ip route get 8.8.8.8 | tr -s ' ' | cut -d' ' -f7 >out.txt

     #! ifconfig | grep HW | awk '{print $5}' >out.txt

      #! ifconfig | grep HW > out.txt
