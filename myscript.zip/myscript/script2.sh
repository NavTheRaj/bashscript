#!/bin/bash

echo $HOSTNAME,$USERNAME > systeminfo.txt


